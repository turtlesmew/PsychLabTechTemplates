﻿using System.Configuration;
using System.Net;
using System.Net.Mail;

namespace $safeprojectname$
{
    public partial class ExitForm : Form
    {
        readonly string fullFormType;

        /// <summary>
        /// Constructor for the Exit Form. Shows a final instruction, text box, and submit button.
        /// </summary>
        /// <param name="formType"> The type of form that was previously shown </param>
        /// <param name="formTime"> The max time for the previous form </param>
        public ExitForm(string formType, string formTime)
        {
            InitializeComponent();

            this.fullFormType = formType + ": " + formTime + " minutes";
        }

        /// <summary>
        /// When the submit button is pressed, the results will be saved as a CSV file as well as email the researchers.
        /// Additionally locks the submit button and text box while updating the label. Automatically closes the program after 5 seconds.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnSubmit(object sender, EventArgs e)
        {
            txtWrittenAns.Enabled = false;
            btnSubmit.Enabled = false;

            lblInstruction.Text = "Thank you for participating in this experiment. This window will now close.";
            lblInstruction.Refresh();

            string htmlBody = "<table class='default' style='border-collapse:collapse;width:100%;'>" +
                    "<tbody><tr><td>Date</td><td>Experiment Type</td><td style = 'null' valign= 'top'>" +
                    " Written Response</td></tr><tr><td>[date]</td><td>[type]</td><td style = 'null' " +
                    "valign= 'top' >[response] </ td ></ tr ></ tbody ></ table >";

            string date = DateTime.Now.ToString("M/d/yyyy h:mm tt");
            string response = txtWrittenAns.Text;

            htmlBody = htmlBody.Replace("[date]", date);
            htmlBody = htmlBody.Replace("[type]", fullFormType);
            htmlBody = htmlBody.Replace("[response]", response);

            //var fromEmail = ConfigurationManager.AppSettings["mail"];
            //var fromPassword = ConfigurationManager.AppSettings["pass"];

            try
            {
                //SendMail("smtp.gmail.com", 587, "sender address", "pass",
                //"add1", "add2", "subject name", htmlBody);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to email response data... Exception: " + ex, "Email Error - This window CAN be closed!", MessageBoxButtons.OK);
            }

            StreamWriter sw = new("results.csv");
            sw.WriteLine("Date, Experiment Type, Written Response");
            sw.WriteLine(date + "," + fullFormType + "," + EscapeSpecialCharacters(response));
            sw.Close();

            Thread.Sleep(5000); //Wait 5 seconds after emailing and writing to file, then close
            Close();

        }

        /// <summary>
        /// This method will escape special characters to be used in a CSV file format and return the safe to use string.
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static string EscapeSpecialCharacters(string data)
        {
            string escapedData = data.Replace("\\R", " ");
            if (data.Contains(',') || data.Contains('"') || data.Contains('\''))
            {
                data = data.Replace("\"", "\"\"");
                escapedData = "\"" + data + "\"";
            }
            return escapedData;
        }

        /// <summary>
        /// Sends an email through gmail SMTP
        /// </summary>
        /// <param name="SMTPServer"> SMTP Server being used to send the email (gmail in this case) </param>
        /// <param name="SMTP_Port"> Expected: 587 </param>
        /// <param name="From"> Sender email address </param>
        /// <param name="Password"> Sender email password (generated in google security) </param>
        /// <param name="To"> Recipient email address </param>
        /// <param name="ccRecipient"> CC recipient email address </param>
        /// <param name="Subject"> Subject line string </param>
        /// <param name="Body"> Body line string </param>
        private static void SendMail(string SMTPServer, int SMTP_Port, string From, string Password, string To, string ccRecipient, string Subject, string Body)
        {
            var smtpClient = new SmtpClient(SMTPServer, SMTP_Port)
            {
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                EnableSsl = true,
                Credentials = new NetworkCredential(From, Password)
            };
            var message = new MailMessage(new MailAddress(From, "Isabelle Johns | Psych 320L Experiment Data"), new MailAddress(To, To));
            message.CC.Add(ccRecipient);
            message.Subject = Subject;
            message.IsBodyHtml = true;
            message.Body = Body;
            smtpClient.Send(message);
        }
    }
}
