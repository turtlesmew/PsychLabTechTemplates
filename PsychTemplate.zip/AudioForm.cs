﻿using $safeprojectname$.Properties;
using System.Diagnostics;

namespace $safeprojectname$
{
    public partial class AudioForm : Form
    {
        // Dictionary of Audio clips as streams in order
        readonly Dictionary<int, Stream> DictAudio = new()
        {
            {1, Stream.Null},
            {2, },
            {3, },
            {4, },
            {5, },
            {6, },
            {7, },
            {8, },
            {9, },
            {10, },
            {11, },
            {12, },
            {13, },
            {14, },
            {15, }
        };

        int currentClip = 1;
        int time;
        readonly string maxTime;

        /// <summary>
        /// Constructor for the Audio Form. Will play 15 audio clips over a given amount of time. User can continue, but not go back.
        /// </summary>
        /// <param name="maxTime"> Max time in seconds to be spent on this form</param>
        public AudioForm(string maxTime)
        {
            InitializeComponent();

            this.maxTime = maxTime;
            if (maxTime.Equals("one"))
                time = 60;
            else
                time = 180;
            lblTimer.Text = "Time Remaining: " + String.Format("{0:0}:{1:00}", time / 60, time % 60);

            PlaySound(currentClip);
        }

        /// <summary>
        /// When the next button is pressed, the next audio clip will be played and the counting label will update. 
        /// Once all 15 audio clips have been played, show the next form.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnNext(object sender, EventArgs e)
        {
            currentClip++;
            if (currentClip <= 15)
            {
                PlaySound(currentClip);
                lblClip.Text = "Audio Clip: " + currentClip + "/15";
            }
            else
            {
                ShowNextForm();
            }
        }

        /// <summary>
        /// When the replay button is pressed, the current audio clip will play again.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnReplay(object sender, EventArgs e)
        {
            PlaySound(currentClip);
            Debug.WriteLine("Playing Sound");
        }

        /// <summary>
        /// Every 1 second, this function will update the timer label to represent the 
        /// current time remaining. If time runs out, go to the next form.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnTimerTick(object sender, EventArgs e)
        {
            time--;
            lblTimer.Text = "Time Remaining: " + String.Format("{0:0}:{1:00}", time / 60, time % 60);
            if (time == 0)
            {
                ShowNextForm();
            }
        }

        /// <summary>
        /// This method will play the current sound while ensuring the stream is at the beginning.
        /// </summary>
        /// <param name="index"></param>
        private void PlaySound(int index)
        {
            Stream sound = DictAudio[index];
            if (sound.CanSeek) sound.Seek(0, SeekOrigin.Begin);
            System.Media.SoundPlayer soundPlayer = new(sound);
            soundPlayer.Play();
        }

        /// <summary>
        /// Creates and shows the final form while passing the info of this form.
        /// </summary>
        private void ShowNextForm()
        {
            ExitForm nextForm = new("audio", maxTime);
            this.Hide();
            nextForm.ShowDialog();
            Close();
        }
    }
}
