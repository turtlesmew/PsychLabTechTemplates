﻿namespace $safeprojectname$
{
    public partial class InstructionForm : Form
    {
        readonly string INSTRUCTIONS = "Instructions go here";
        string formTime;
        string formType;

        /// <summary>
        /// Constructor for the Instruction Form. Shows instructions based on which form is to be loaded next.
        /// </summary>
        /// <param name="formType"> Type of form to be loaded next </param>
        /// <param name="formTime"> Time for the form to be loaded next </param>
        public InstructionForm(string formType, string formTime)
        {
            InitializeComponent();

            this.formTime = formTime;
            this.formType = formType;

            //Example 
            //string instructString = lblInstruction.Text;


            //instructString = instructString.Replace("<time>", formTime);

            //if (formType.Equals("image"))
            //{
            //    instructString = instructString.Replace("<task>", "shown fifteen images");
            //    instructString = instructString.Replace("<task-short>", "look them over");
            //    instructString = instructString.Replace("<task-medium>", "looking at the images");
            //    instructString = instructString.Replace("<extra>", "a");
            //}
            //else
            //{
            //    instructString = instructString.Replace("<task>", "listening to fifteen different words");
            //    instructString = instructString.Replace("<task-short>", "listen to them");
            //    instructString = instructString.Replace("<task-medium>", "listening to the audio");
            //    instructString = instructString.Replace("<extra>", "a repeat button for each word for you to replay along with a");
            //}

            lblInstruction.Text = INSTRUCTIONS;
        }

        /// <summary>
        /// When the next button is pressed, create the new form based on formType and formTime.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnNext(object sender, EventArgs e)
        {
            Form nextForm;

            if (formType.Equals("image"))
            {
                nextForm = new PictureForm(formTime);
            }
            //This template shows an example of using another form
            else
            {
                nextForm = new AudioForm(formTime);
            }

            this.Hide();
            nextForm.ShowDialog();
            Close();
        }
    }
}
