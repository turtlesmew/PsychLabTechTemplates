namespace $safeprojectname$
{
    public partial class MainForm : Form
    {
        // This template has 2 modes. one minute, three minute, five minutes, and 7 minutes.
        private readonly string oneMinKey = "A";
        private readonly string threeMinKey = "B";
        private readonly string fiveMinKey = "C";
        public MainForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// When the continue button is pressed, a new windows form will be loaded based on the given key.
        /// Options include: One minute image form, three minute image form, five minute image form, or seven minute image form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnContinue(object sender, EventArgs e)
        {
            string subjectCode = txtSubjectCode.Text.ToUpper();

            InstructionForm nextForm;

            if (subjectCode.Contains(oneMinKey))
                nextForm = new InstructionForm("image", "one");
            else if (subjectCode.Contains(threeMinKey))
                nextForm = new InstructionForm("image", "three");
            else if (subjectCode.Contains(fiveMinKey))
                nextForm = new InstructionForm("image", "five");
            else
                nextForm = new InstructionForm("image", "seven");

            this.Hide();
            nextForm.ShowDialog();
            Close();
        }

    }
}