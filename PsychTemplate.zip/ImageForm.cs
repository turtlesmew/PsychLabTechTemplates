﻿using $safeprojectname$.Properties;

namespace $safeprojectname$
{
    public partial class PictureForm : Form
    {
        // Dictionary containing the images as bitmaps in order
        readonly Dictionary<int, Bitmap> DictImages = new()
        {
            {1, Resources.cat_image},
            {2, Resources.cloud_image},
            {3, Resources.tree_image},
            {4, Resources.flower_image},
            {5, Resources.lamp_image},
            {6, Resources.duck_image},
            {7, Resources.musicnote_image},
            {8, Resources.flag_image},
            {9, Resources.dog_image},
            {10, Resources.map_image},
            {11, Resources.swing_image},
            {12, Resources.dress_image},
            {13, Resources.bicycle_image},
            {14, Resources.cupcake_image},
            {15, Resources.tub_image}
        };

        int currentImage = 1;
        int time;
        readonly string maxTime;

        /// <summary>
        /// Constructor for the Images Form. Will show 15 images over a given amount of time. User can continue, but not go back.
        /// </summary>
        /// <param name="maxTime"> Max time in seconds to be spent on this form </param>
        public PictureForm(string maxTime)
        {
            InitializeComponent();

            this.maxTime = maxTime;
            if (maxTime.Equals("one"))
                time = 60;
            else if (maxTime.Equals("three"))
                time = 3 * 60;
            else if (maxTime.Equals("five"))
                time = 5 * 60;
            else
                time = 7 * 60;

            lblTimer.Text = "Time Remaining: " + String.Format("{0:0}:{1:00}", time / 60, time % 60);
        }

        /// <summary>
        /// Every 1 second, this function will update the timer label to represent the 
        /// current time remaining. If time runs out, go to the next form.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnTimerTick(object sender, EventArgs e)
        {
            time--;
            lblTimer.Text = "Time Remaining: " + String.Format("{0:0}:{1:00}", time / 60, time % 60);
            if (time == 0)
            {
                ShowNextForm();
            }
        }

        /// <summary>
        /// When the next button is pressed, update the image being displayed and the counting label. Once all 15 images have been shown,
        /// show the next form.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnNext(object sender, EventArgs e)
        {
            currentImage++;
            if (currentImage <= 15)
            {
                pboxImage.Image = DictImages[currentImage];
                lblSlide.Text = "Image: " + currentImage + "/" + DictImages.Count;
            }
            else
            {
                ShowNextForm();
            }
        }

        /// <summary>
        /// Creates and shows the final form while passing the info of this form.
        /// </summary>
        private void ShowNextForm()
        {
            ExitForm nextForm = new("image", maxTime);
            this.Hide();
            nextForm.ShowDialog();
            Close();
        }
    }
}
