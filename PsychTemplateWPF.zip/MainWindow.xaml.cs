﻿using Microsoft.Office.Interop.Excel;
using Microsoft.Win32;
using $safeprojectname$.Models;
using System;
using System.ComponentModel;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Navigation;
using _excel = Microsoft.Office.Interop.Excel;
using Window = System.Windows.Window;

namespace $safeprojectname$
{
    /// <summary>
    /// Main window for the entire application.
    /// </summary>
    public partial class MainWindow : Window
    {
        private User user;
        public MainWindow()
        {
            InitializeComponent();

            NavigationCommands.BrowseBack.InputGestures.Clear();        // Disables going to the previous page via Keypress
            NavigationCommands.BrowseForward.InputGestures.Clear();     // Disables going to the next page via Keypress

            user = new User();  // Create a new user to pass to the rest of the application

            IntroductionPage introductionPage = new()
            {
                user = this.user
            };

            frmMain.Navigate(introductionPage); //Load the first page into the frame (What holds the pages)
        }

        /// <summary>
        /// Overrides the OnClosing event. Whenever the application is closed, 
        /// it will attempt to save an excel file with the results of the user.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnClosing(CancelEventArgs e)
        {
            ExportAnswers();
            base.OnClosing(e);
        }

        /// <summary>
        /// Exports all the user's answers to an excel file. The researcher will need to select where to save the file, and what to call it. 
        /// I opted for this method because the researchers can forget how to get data if they are not manually saving it.
        /// </summary>
        private void ExportAnswers()
        {
            SaveFileDialog saveFileDialog = new()
            {
                Filter = "Excel files (*.xlsx)|*.xlsx",
                FilterIndex = 0,
                RestoreDirectory = true,
                Title = "Export Excel File To"
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                // Potentional TODO: open the same excel file and add onto it
                try
                {
                    _Application excel = new _excel.Application();
                    Workbook workbook = excel.Workbooks.Add(XlWBATemplate.xlWBATWorksheet);              
                    Worksheet worksheet = workbook.Worksheets[1];

                    worksheet.Cells[1, 1] = "Time Submitted";
                    worksheet.Cells[2, 1] = DateTime.Now.ToString();

                    worksheet.Cells[1, 2] = "Experiment Type";
                    worksheet.Cells[2, 2] = user.strType;

                    int currentColumn = 3;

                    foreach (var item in user.dictAnswers)
                    {
                        var question = item.Key;
                        var answer = item.Value;

                        worksheet.Cells[1, currentColumn] = question;
                        worksheet.Cells[2, currentColumn] = answer;
                        currentColumn++;
                    }

                    foreach (var item in user.dictSurvey)
                    {
                        var question = item.Key;
                        var answer = item.Value;

                        worksheet.Cells[1, currentColumn] = question;
                        worksheet.Cells[2, currentColumn] = answer;
                        currentColumn++;
                    }

                    workbook.SaveAs(saveFileDialog.FileName, XlFileFormat.xlWorkbookDefault);
                    workbook.Close(true);

                    Marshal.ReleaseComObject(excel);
                    Marshal.ReleaseComObject(workbook);
                    Marshal.ReleaseComObject(worksheet);
                }


                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
