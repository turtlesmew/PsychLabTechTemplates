﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Models
{
    /// <summary>
    /// Holds the data of the user's answers
    /// </summary>
    public class User
    {
        public string strType;
        public Dictionary<string, string> dictAnswers;
        public Dictionary<string, string> dictSurvey;

        public User()
        {
            strType = string.Empty;
            dictAnswers = new Dictionary<string, string>();
            dictSurvey = new Dictionary<string, string>();
        }

        /// <summary>
        /// Add a new value to the Answers Dictionary
        /// </summary>
        /// <param name="strQuestion"> Question asked </param>
        /// <param name="strAnswer"> Answer provided </param>
        public void AddAnswer(string strQuestion, string strAnswer)
        {
            dictAnswers.Add(strQuestion, strAnswer);
        }

        /// <summary>
        /// Add a new value to the Survey Dictionary
        /// </summary>
        /// <param name="strQuestion"> Question asked </param>
        /// <param name="strAnswer"> Answer provided </param>
        public void AddSurvey(string strQuestion, string strAnswer)
        {
            dictSurvey.Add(strQuestion, strAnswer);
        }
    }
}
