﻿using $safeprojectname$.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace $safeprojectname$
{
    /// <summary>
    /// Page that shows the Instructions to the User
    /// </summary>
    public partial class InstructionsPage : Page
    {
        private readonly string strType;    // Type of experiment
        private readonly TimeSpan time;     // Max time for the experiment
        public User? user;                  // Reference to the User
        public string InstructionString { get; set; }   // Instructions shown to the User
        public InstructionsPage(string strType, TimeSpan time)
        {
            InitializeComponent();

            DataContext = this;

            this.strType = strType;
            this.time = time;

            InstructionString = "Instructions for the person would go here.";
        }

        /// <summary>
        /// Handles the onClick for the Continue button to move on to the
        /// correct experiment.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (user != null)
            {
                user.strType = strType;
            }

            if(strType == "Image")
            {
                ImagePage imagePage = new(time)
                {
                    user = this.user
                };

                NavigationService.Navigate(imagePage);
            }
            else
            {
                TextPage textPage = new(time)
                {
                    user = this.user
                };

                NavigationService.Navigate(textPage);
            }
            
        }
    }
}
