﻿using $safeprojectname$.Models;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using System.Windows.Threading;

namespace $safeprojectname$
{
    /// <summary>
    /// Image Page shows 3 Images to the user to select from
    /// </summary>
    public partial class ImagePage : Page
    {
        private readonly double _iterations;        // Max number of questions
        private readonly TimeSpan _maxTime;         // Max time given to the user
        private TimeSpan _time;                     // Current time left
        readonly DispatcherTimer dispatcherTimer;   // Timer
        public User? user;                          // Reference to the User
        public ImagePage(TimeSpan time)
        {
            InitializeComponent();

            _iterations = pbStatus.Maximum;
            _maxTime = time;
            _time = _maxTime;
            lblTime.Content = _time.ToString(@"mm\:ss");

            dispatcherTimer = new DispatcherTimer();
            
            dispatcherTimer.Tick += DispatcherTimer_Tick;
            dispatcherTimer.Interval = new TimeSpan(0, 0, 1);

            dispatcherTimer.Start();
        }

        /// <summary>
        /// Subtracts time from the timer every 1 second
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DispatcherTimer_Tick(object? sender, EventArgs e)
        {
            if(_time.TotalSeconds > 0)
            {
                _time = _time.Subtract(new TimeSpan(0,0,1));
                lblTime.Content = _time.ToString(@"mm\:ss");    // Show time left on the label
            }
            else
            {
                dispatcherTimer.Stop();
                SurveyPage surveyPage = new()
                {
                    user = this.user!
                };

                NavigationService.Navigate(surveyPage);
            }
             
        }

        /// <summary>
        /// Handles the onClick event for all buttons.
        /// Will add the button's tag as the option selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button btnSender = (Button)sender;

            user!.AddAnswer((pbStatus.Value + 1).ToString(),btnSender.Tag.ToString()!);

            if(pbStatus.Value < _iterations - 1)
            {
                pbStatus.Value += 1;
            }
            else
            {
                dispatcherTimer.Stop();
                SurveyPage surveyPage = new()
                {
                    user = this.user
                };

                NavigationService.Navigate(surveyPage);
            }
            
        }
    }
}
