﻿using $safeprojectname$.Models;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace $safeprojectname$
{
    /// <summary>
    /// Initial Page shown to the user
    /// </summary>
    public partial class IntroductionPage : Page
    {
        // Change these values to match with what the researchers want to enter.
        private readonly string _keyOne = "A";
        private readonly string _keyTwo = "B";
        private readonly string _keyThree = "C";
        public User? user;

        public IntroductionPage()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the onClick for the continue button. Will move on to the instructions
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string strKey = txtEntry.Text.ToUpper();

            TimeSpan time;
            string strType;

            /// These are something the researchers need to decide. 
            /// Some experiments don't require a time limit, and some don't require different versions.
            /// Use TimeSpan as such: TimeSpan(Hours, Minutes, Seconds)
            if (strKey.StartsWith(_keyOne))
            {
                strType = "Image";
                time = new TimeSpan(0, 3, 0);
            }
            else if (strKey.StartsWith(_keyTwo))
            {
                strType = "Text";
                time = new TimeSpan(0, 1, 0);
            }
            else if (_keyTwo.StartsWith(_keyThree))
            {
                strType = "Image";
                time = new TimeSpan(0, 3, 0);
            }
            else
            {
                strType = "Text";
                time = new TimeSpan(0, 1, 0);
            }

            InstructionsPage instructionsPage = new(strType, time)
            {
                user = user
            };

            NavigationService.Navigate(instructionsPage);

        }
    }
}
