﻿using $safeprojectname$.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace $safeprojectname$
{
    /// <summary>
    /// This Page shows the Survey to the User
    /// </summary>
    public partial class SurveyPage : Page
    {
        public User? user;
        public SurveyPage()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if(user != null)
            {
                // Add each question and answer pair
                user.AddSurvey(lblQuestion1.Content.ToString()!, cmbAnswer1.Text);
                user.AddSurvey(lblQuestion2.Content.ToString()!, txtAnswer2.Text);
                user.AddSurvey(lblQuestion3.Content.ToString()!, txtAnswer3.Text);
                user.AddSurvey(lblQuestion4.Content.ToString()!, cmbAnswer4.Content.ToString()!);
            }


            NavigationService.Navigate(new ThankYouPage());
        }
    }
}
