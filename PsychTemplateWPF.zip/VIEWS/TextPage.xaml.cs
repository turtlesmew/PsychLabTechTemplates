﻿using $safeprojectname$.Models;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Navigation;
using System.Windows.Threading;

namespace $safeprojectname$
{
    /// <summary>
    /// Text Page shows 1 question for the user to answer
    /// </summary>
    public partial class TextPage : Page
    {
        private readonly double _iterations;                // Max number of questions
        private readonly TimeSpan _maxTime;                 // Max time given to the user
        private TimeSpan _time;                             // Current time left
        private readonly DispatcherTimer dispatcherTimer;   // Timer
        public User? user;                                  // Reference to the User

        // List of questions (Hardcoded - get from the researchers) 
        public string[] questions = new string[] 
        {
            "3x3 =",
            "1x6 =",
            "6x8 =",
            "3x9 =",
            "4x5 ="
        };
        public TextPage(TimeSpan time)
        {
            InitializeComponent();

            _iterations = questions.Length;
            pbStatus.Maximum = _iterations;
            _maxTime = time;
            _time = _maxTime;

            lblQuestion.Content = questions[0];
            lblTime.Content = _time.ToString(@"mm\:ss");

            dispatcherTimer = new DispatcherTimer();

            dispatcherTimer.Tick += DispatcherTimer_Tick;
            dispatcherTimer.Interval = new TimeSpan(0, 0, 1);

            dispatcherTimer.Start();
        }

        /// <summary>
        /// Subtracts time from the timer every 1 second
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DispatcherTimer_Tick(object? sender, EventArgs e)
        {
            if (_time.TotalSeconds > 0)
            {
                _time = _time.Subtract(new TimeSpan(0, 0, 1));
                lblTime.Content = _time.ToString(@"mm\:ss");
            }
            else
            {
                dispatcherTimer.Stop();
                SurveyPage surveyPage = new()
                {
                    user = user
                };

                NavigationService.Navigate(surveyPage);
            }
        }

        /// <summary>
        /// Handles the onClick event for the button.
        /// Will add the text provided, or "skip" if no answer given.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int current = (int)pbStatus.Value;

            user!.AddAnswer(questions[current], string.IsNullOrEmpty(txtAnswer.Text) ? "Skip" : txtAnswer.Text);

            txtAnswer.Clear();

            if (current < _iterations - 1)
            {
                current += 1;
                lblQuestion.Content = questions[current];

                pbStatus.Value = current;
            }
            else
            {
                dispatcherTimer.Stop();
                SurveyPage surveyPage = new()
                {
                    user = user
                };

                NavigationService.Navigate(surveyPage);
            }

        }

        /// <summary>
        /// Allows the user to press "Enter" while in the textbox to move on
        /// to the next question
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtAnswer_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Enter)
            {
                Button_Click(sender, e);
                txtAnswer.Clear();
            }
        }
    }
}
